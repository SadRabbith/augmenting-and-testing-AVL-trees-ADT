/**
 * Performs insertions and searches, using the same data set,on a binary search
 * tree and an AVL tree to compare the empirically compare the performance of
 * these operations on the trees.
 * @author Duncan, Sadman Raabith
 * @SEE AVLTree, AVLTree.h, AVLTreeException
 * <pre>
 * Date: DATE LAST MODIFIED
 * Course: csc 3102 section x 
 * Programming Project: 2 
 * Instructor: Dr. Duncan
 * </pre>
 */
#include <iostream>
#include <cstdlib>  
#include <stdexcept>
#include <iomanip>
#include <fstream> 
#include<algorithm>
#include "AVLTree.cpp"

using namespace std;

/**
 * Converts the specified string to uppercase
 * @param w a string
 * @return the uppercase version of the specified string
 */
string toUpper(string w)
{
   transform(w.begin(), w.end(),w.begin(),::toupper);
   return w;
}

int main(int argc, char** argv) 
{
   string usage = "Harvester <command-file-name>\n";
   usage += "The command file name is entered as a command line argumet.\n";
   usage += "The command file consists of instructions in one of these formats:.\n";
   usage += "insert <word>\n";
   usage += "remove <word>\n";
   usage += "traverse\n";
   usage += "props";
   if (argc != 2)
   {
      cout<<usage<<endl;
      exit(1);
   }
   //Complete the Implementation of this function
   // 1. First instantiate the tree using the default constructor
   AVLTree<string> tree;

   // 2. After you get everything to work, comment out the line that
   //    instantiates the tree using the default constructor, an
   //    instantiate the tree using the parameterized constructor using
   //    a comparator that compares strings using the lengths, resolving,
   //	  ties using the lexicographical order of the string, rather than
   //    than their lexicographical order; that is, +len+lex order.

   //lexicographical order

   string commandFileName = argv[1];
   ifstream commandFile(commandFileName);
   if (!commandFile) {
      cerr << "Error opening command file: " << commandFileName << endl;
      exit(1);
   }

   // output files
   ofstream lexOut("testlex.out");
   ofstream lenOut("testlen.out");

   if (!lexOut || !lenOut) {
      cerr << "Error opening output files!" << endl;
      exit(1);
   }

   // default comparator (lexicographical order)
   AVLTree<string> lexTree;

   // parameterized constructor for string-length + lexicographical comparator
   auto lenLexComparator = [](const string &a, const string &b) {
      if (a.length() != b.length()) {
         return static_cast<int>(a.length() - b.length());
      }
      return a.compare(b); // this resolves ties lexicographically
   };
   AVLTree<string> lenLexTree(lenLexComparator);


   string command;
   while (commandFile >> command) {
      if (command == "insert") {
         string word;
         commandFile >> word;
         word = toUpper(word);

         lexTree.insert(word);
         lexOut<<"inserted: "<<word<<" in the AVL tree at a depth of "<< lexTree.depth(word) <<"."<< endl;
         lexOut<<endl;

         lenLexTree.insert(word);
         lenOut<<"inserted: "<<word<<" in the AVL tree at a depth of "<< lenLexTree.depth(word) <<"."<< endl;
         lenOut<<endl;
      }
      else if (command == "remove") {
         string word;
         commandFile >> word;
         word = toUpper(word);
         int depth = lexTree.depth(word);
         lexTree.remove(word);
         lexOut<<"removed: "<<word<<" in the AVL tree at a depth of "<< depth <<"."<< endl;
         lexOut<<endl;

         depth = lenLexTree.depth(word);
         lenLexTree.remove(word);
         lenOut<<"removed: "<<word<<" in the AVL tree at a depth of "<< depth <<"."<< endl;
         lenOut<<endl;

      }
      else if (command == "traverse") {
         // traversing lexicographical tree
    	 lexOut<<"In order:"<<endl;
    	 lexOut<<"------------------------------------"<<endl;

         lexTree.traverse([&lexOut, &lexTree](const string &word) {
            lexOut << word << endl;
            lexOut<<endl;

         });
         lexOut << endl;
         lexOut<<"------------------------------------"<<endl;
         lexOut<<"WordCount= "<<lexTree.size()<<endl;
         lexOut<<endl;


         // traversing length-based tree and writing output to lenOut
         lenOut<<"In order:"<<endl;
         lenOut<<"------------------------------------"<<endl;
         lenOut << "Length + Lexicographical Traverse:" << endl;
         lenLexTree.traverse([&lenOut, &lenLexTree](const string &word) {
            lenOut << word << endl;
            lenOut<<endl;


         });
         lenOut << endl;
         lenOut<<"------------------------------------"<<endl;
         lenOut<<"WordCount= "<<lenLexTree.size()<<endl;
         lenOut<<endl;


      }
      else if (command == "props") {

         lexOut << "Lexicographical Tree Properties:" << endl;
         lexOut << "Size: " << lexTree.size() << endl;
         lexOut << "Height: " << lexTree.height() << endl;
         lexOut << "Is full: " << (lexTree.isFull() ? "Yes" : "No") << endl;
         lexOut << "Is complete: " << (lexTree.isComplete() ? "Yes" : "No") << endl;
         lexOut<<endl;


         lenOut << "Length + Lexicographical Tree Properties:" << endl;
         lenOut << "Size: " << lenLexTree.size() << endl;
         lenOut << "Height: " << lenLexTree.height() << endl;
         lenOut << "Is full: " << (lenLexTree.isFull() ? "Yes" : "No") << endl;
         lenOut << "Is complete: " << (lenLexTree.isComplete() ? "Yes" : "No") << endl;
         lenOut<<endl;
      }
   }

   // closing the files
   commandFile.close();
   lexOut.close();
   lenOut.close();

   return 0;
}

